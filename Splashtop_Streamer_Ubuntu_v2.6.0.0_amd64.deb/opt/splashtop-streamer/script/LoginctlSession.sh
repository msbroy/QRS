#!/bin/bash
substr=$(
for sessionid in $(loginctl list-sessions --no-legend | awk '{ print $1 }')
do loginctl show-session -p Id -p Name -p User -p State -p Type -p Remote -p Display $sessionid | sort
done |
awk -F= '/Name/ { name = $2 } /User/ { user = $2 } /State/ { state = $2 } /Type/ { type = $2 } /Remote/ { remote = $2 } /Display/ { display = $2 } /User/ && remote == "no" && state == "active" && (type == "x11" || type == "wayland") { print user, name, display }'
)
if [ ! -z $1 ] && [ "-uuid" == $1 ]; then
	Uid="UID="$(echo $substr | cut -d" " -f 1)
	echo $Uid;
	exit 0
fi
if [ ! -z $1 ] && [ "-auth" == $1 ]; then
	AuthPath="XAUPATH=/var/run/sddm/"$(ls /var/run/sddm/)
	echo $AuthPath;
	exit 0
fi
Uid="UID="$(echo $substr | cut -d" " -f 1)
User="USER="$(echo $substr | cut -d" " -f 2)
Display="DISPLAY="$(echo $substr | cut -d" " -f 3)
if [ "$(lsb_release -r | awk '{ print $2 }')" != "16.04" ]; then
	if [ $User != "USER=gdm" ] && [ $User != "USER=lightdm" ]; then 
		DisplayID=`w -h $(echo $substr | cut -d" " -f 2) | awk '$3 ~ /:[0-9.]*/{print $3}'`
		Display="DISPLAY="$DisplayID
	fi
fi
echo $Uid;echo $Display;echo $User
exit 0

loginctl list-sessions --no-legend | awk  '{print $1}' | {
while read line
do
	sid=$line
	loginctl show-session -p Active -p Display "$sid" | {
	bDisplay=false
	while IFS='=' read property value; do
		case "$property" in
			Display)
				if [[ "$value" ]]; then
					bDisplay=true;DISPLAY=$value
				fi
				;;
			Active)
				if [ "$value" != "yes" ] || [ $bDisplay == false ]; then break; fi
				export TARGET_DISPLAY=$DISPLAY
				echo $TARGET_DISPLAY
				#else the session isn't GUI
				;;
		esac
	done
	}
done
}

