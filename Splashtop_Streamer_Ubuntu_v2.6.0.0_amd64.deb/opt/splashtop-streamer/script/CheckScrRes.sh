#!/bin/bash
x=`xdpyinfo | grep dimensions | sed -r 's/^[^0-9]*([0-9]+x[0-9]+).*$/\1/' | cut -d'x' -f 1`
y=`xdpyinfo | grep dimensions | sed -r 's/^[^0-9]*([0-9]+x[0-9]+).*$/\1/' | cut -d'x' -f 2`
if [ $(((x/2)*2)) != $x ]; then
	echo "Please adjust screen resolution for SplashTop Streamer"
	killall SRFeature
	exit 1
fi
if [ $(((y/2)*2)) != $y ]; then
	echo "Please adjust screen resolution for SplashTop Streamer"
	killall SRFeature
	exit 1
fi
exit 0
